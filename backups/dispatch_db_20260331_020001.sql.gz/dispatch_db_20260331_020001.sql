--
-- PostgreSQL database dump
--

\restrict Zrb6mixfkUzIJCbpHnsENQSgG0VQRVXbWywNY64QKrgHubonIldnKiQ3X5Rsku7

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dispatch_secure
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dispatch_secure;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: dispatch_secure
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blocked_users; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.blocked_users (
    id integer NOT NULL,
    user_id integer NOT NULL,
    blocked_user_id integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.blocked_users OWNER TO dispatch_secure;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.blocked_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blocked_users_id_seq OWNER TO dispatch_secure;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.blocked_users_id_seq OWNED BY public.blocked_users.id;


--
-- Name: chat_conversations; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.chat_conversations (
    id integer NOT NULL,
    user1_id integer NOT NULL,
    user2_id integer NOT NULL,
    status character varying(20),
    initiator_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.chat_conversations OWNER TO dispatch_secure;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.chat_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_conversations_id_seq OWNER TO dispatch_secure;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.chat_conversations_id_seq OWNED BY public.chat_conversations.id;


--
-- Name: chat_groups; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.chat_groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_by_id integer NOT NULL,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.chat_groups OWNER TO dispatch_secure;

--
-- Name: chat_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.chat_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_groups_id_seq OWNER TO dispatch_secure;

--
-- Name: chat_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.chat_groups_id_seq OWNED BY public.chat_groups.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    encrypted_content text NOT NULL,
    created_at timestamp without time zone,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO dispatch_secure;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO dispatch_secure;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.files (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    recipient_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    encrypted_filename character varying(255) NOT NULL,
    file_size bigint NOT NULL,
    status character varying(20),
    options text,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    downloaded_at timestamp without time zone,
    stealth_mode boolean
);


ALTER TABLE public.files OWNER TO dispatch_secure;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO dispatch_secure;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: group_chat_messages; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.group_chat_messages (
    id integer NOT NULL,
    group_id integer NOT NULL,
    sender_id integer NOT NULL,
    encrypted_content text NOT NULL,
    message_type character varying(20),
    voice_duration integer,
    created_at timestamp without time zone,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.group_chat_messages OWNER TO dispatch_secure;

--
-- Name: group_chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.group_chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_chat_messages_id_seq OWNER TO dispatch_secure;

--
-- Name: group_chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.group_chat_messages_id_seq OWNED BY public.group_chat_messages.id;


--
-- Name: group_invitations; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.group_invitations (
    id integer NOT NULL,
    group_id integer NOT NULL,
    inviter_id integer NOT NULL,
    invited_user_id integer NOT NULL,
    status character varying(20),
    created_at timestamp without time zone
);


ALTER TABLE public.group_invitations OWNER TO dispatch_secure;

--
-- Name: group_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.group_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_invitations_id_seq OWNER TO dispatch_secure;

--
-- Name: group_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.group_invitations_id_seq OWNED BY public.group_invitations.id;


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.group_members (
    id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(20),
    joined_at timestamp without time zone,
    last_read_at timestamp without time zone
);


ALTER TABLE public.group_members OWNER TO dispatch_secure;

--
-- Name: group_members_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.group_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_members_id_seq OWNER TO dispatch_secure;

--
-- Name: group_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.group_members_id_seq OWNED BY public.group_members.id;


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.login_history (
    id integer NOT NULL,
    user_id integer NOT NULL,
    login_time timestamp without time zone
);


ALTER TABLE public.login_history OWNER TO dispatch_secure;

--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.login_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_history_id_seq OWNER TO dispatch_secure;

--
-- Name: login_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.login_history_id_seq OWNED BY public.login_history.id;


--
-- Name: message_reactions; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.message_reactions (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    reaction_type character varying(20) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.message_reactions OWNER TO dispatch_secure;

--
-- Name: message_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.message_reactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_reactions_id_seq OWNER TO dispatch_secure;

--
-- Name: message_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.message_reactions_id_seq OWNED BY public.message_reactions.id;


--
-- Name: message_read_receipts; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.message_read_receipts (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone
);


ALTER TABLE public.message_read_receipts OWNER TO dispatch_secure;

--
-- Name: message_read_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.message_read_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_read_receipts_id_seq OWNER TO dispatch_secure;

--
-- Name: message_read_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.message_read_receipts_id_seq OWNED BY public.message_read_receipts.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    user_id integer NOT NULL,
    recipient_id integer NOT NULL,
    encrypted_message text NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    is_read boolean
);


ALTER TABLE public.messages OWNER TO dispatch_secure;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO dispatch_secure;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount integer NOT NULL,
    plan character varying(20) NOT NULL,
    xmr_amount character varying(50) NOT NULL,
    xmr_address character varying(255) NOT NULL,
    status character varying(20),
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO dispatch_secure;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO dispatch_secure;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    twofa_verified boolean
);


ALTER TABLE public.sessions OWNER TO dispatch_secure;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO dispatch_secure;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: user_keys; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.user_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    public_key text NOT NULL,
    encrypted_private_key text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.user_keys OWNER TO dispatch_secure;

--
-- Name: user_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.user_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_keys_id_seq OWNER TO dispatch_secure;

--
-- Name: user_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.user_keys_id_seq OWNED BY public.user_keys.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: dispatch_secure
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    pin_hash character varying(255) NOT NULL,
    recovery_phrase_hash character varying(255) NOT NULL,
    role character varying(20),
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    theme character varying(10),
    is_banned boolean,
    ban_reason text,
    subscription_expires_at timestamp without time zone,
    failed_login_attempts integer,
    last_failed_login timestamp without time zone,
    totp_secret character varying(100),
    totp_enabled boolean,
    recovery_codes_hash text,
    read_receipts_enabled boolean DEFAULT true,
    bio text
);


ALTER TABLE public.users OWNER TO dispatch_secure;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_secure
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dispatch_secure;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_secure
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: blocked_users id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.blocked_users ALTER COLUMN id SET DEFAULT nextval('public.blocked_users_id_seq'::regclass);


--
-- Name: chat_conversations id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_conversations ALTER COLUMN id SET DEFAULT nextval('public.chat_conversations_id_seq'::regclass);


--
-- Name: chat_groups id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_groups ALTER COLUMN id SET DEFAULT nextval('public.chat_groups_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: group_chat_messages id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_chat_messages ALTER COLUMN id SET DEFAULT nextval('public.group_chat_messages_id_seq'::regclass);


--
-- Name: group_invitations id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_invitations ALTER COLUMN id SET DEFAULT nextval('public.group_invitations_id_seq'::regclass);


--
-- Name: group_members id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_members ALTER COLUMN id SET DEFAULT nextval('public.group_members_id_seq'::regclass);


--
-- Name: login_history id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.login_history ALTER COLUMN id SET DEFAULT nextval('public.login_history_id_seq'::regclass);


--
-- Name: message_reactions id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_reactions ALTER COLUMN id SET DEFAULT nextval('public.message_reactions_id_seq'::regclass);


--
-- Name: message_read_receipts id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_read_receipts ALTER COLUMN id SET DEFAULT nextval('public.message_read_receipts_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: user_keys id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.user_keys ALTER COLUMN id SET DEFAULT nextval('public.user_keys_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: blocked_users; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.blocked_users (id, user_id, blocked_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: chat_conversations; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.chat_conversations (id, user1_id, user2_id, status, initiator_id, created_at, updated_at) FROM stdin;
2	1	2	pending	1	2026-03-30 21:49:41.235604	2026-03-30 21:49:41.235629
1	1	3	active	1	2026-03-30 17:14:43.103688	2026-03-30 22:47:47.5815
\.


--
-- Data for Name: chat_groups; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.chat_groups (id, name, description, created_by_id, created_at, is_active) FROM stdin;
1	Dispatch	hello	1	2026-03-30 17:20:24.277391	t
4	Burger	hhahaha	1	2026-03-30 22:09:16.233924	t
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.chat_messages (id, conversation_id, sender_id, encrypted_content, created_at, delivered_at, read_at, expires_at) FROM stdin;
1	1	1	hellooooooo	2026-03-30 17:16:24.091447	2026-03-30 17:16:24.086275	2026-03-30 17:26:09.635469	2026-03-31 17:16:24.086217
2	1	1	dddddd	2026-03-30 18:36:48.626248	2026-03-30 18:36:48.618537	2026-03-30 19:10:25.400739	2026-03-31 18:36:48.61848
3	1	1	j	2026-03-30 22:47:47.544404	2026-03-30 22:47:47.539538	\N	2026-03-31 22:47:47.53948
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.files (id, sender_id, recipient_id, filename, encrypted_filename, file_size, status, options, created_at, expires_at, accepted_at, downloaded_at, stealth_mode) FROM stdin;
2	1	3	0f766e.png	ad1b64d5312c03aba2885b279867d0c8ef1e5bff45b1412f1b6f978f93778c10.enc	6821	declined	{"custom_expiry": 1}	2026-03-29 12:32:41.076546	2026-04-01 12:32:41.06987	\N	\N	f
3	1	3	rules.docx	61cdb7dbc047afa1b9c1ae7cc0a6851c3265914761231e85cf256df0292cbea8.enc	27578	accepted	{}	2026-03-29 12:33:53.876468	2026-04-05 12:34:56.297844	2026-03-29 12:34:56.298012	\N	f
4	1	3	0f766e.png	7e34375df9f8dca217ef6f08ba7b965545e40c7773faa9909051f2f68b9fae1b.enc	6821	cancelled	{}	2026-03-30 15:30:42.279912	2026-04-02 15:30:42.273238	\N	\N	\N
\.


--
-- Data for Name: group_chat_messages; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.group_chat_messages (id, group_id, sender_id, encrypted_content, message_type, voice_duration, created_at, delivered_at, read_at, expires_at) FROM stdin;
1	1	1	hello	text	\N	2026-03-30 17:20:57.32505	2026-03-30 17:20:57.319671	\N	2026-03-31 17:20:57.319616
2	1	3	Hi	text	\N	2026-03-30 19:11:31.472421	2026-03-30 19:11:31.46691	\N	2026-03-31 19:11:31.466856
3	4	3	Hello	\N	\N	2026-03-30 22:10:32.550426	2026-03-30 22:10:32.545348	\N	2026-03-31 22:10:32.545293
4	4	1	hello	\N	\N	2026-03-30 22:12:58.872868	2026-03-30 22:12:58.870861	\N	2026-03-31 22:12:58.870806
5	4	1	how are you?	\N	\N	2026-03-30 22:13:08.33277	2026-03-30 22:13:08.330839	\N	2026-03-31 22:13:08.330786
6	4	3	F	\N	\N	2026-03-30 22:14:25.11431	2026-03-30 22:14:25.112372	\N	2026-03-31 22:14:25.112319
7	4	1	n	\N	\N	2026-03-30 22:25:08.919978	2026-03-30 22:25:08.915408	\N	2026-03-31 22:25:08.915352
8	4	1	m	\N	\N	2026-03-30 22:25:10.593602	2026-03-30 22:25:10.591556	\N	2026-03-31 22:25:10.5915
9	4	1	m	\N	\N	2026-03-30 22:25:12.488377	2026-03-30 22:25:12.48639	\N	2026-03-31 22:25:12.486335
10	4	1	m	\N	\N	2026-03-30 22:25:16.286857	2026-03-30 22:25:16.284868	\N	2026-03-31 22:25:16.284815
11	4	1	n	\N	\N	2026-03-30 22:25:22.078736	2026-03-30 22:25:22.076757	\N	2026-03-31 22:25:22.076702
12	4	1	m	\N	\N	2026-03-30 22:25:23.484002	2026-03-30 22:25:23.481994	\N	2026-03-31 22:25:23.481942
13	4	1	k	\N	\N	2026-03-30 22:25:30.520464	2026-03-30 22:25:30.518462	\N	2026-03-31 22:25:30.518408
14	4	3	Hello!	\N	\N	2026-03-31 00:31:38.688093	2026-03-31 00:31:38.682816	\N	2026-04-01 00:31:38.682762
15	4	3	Hru	\N	\N	2026-03-31 00:31:43.702067	2026-03-31 00:31:43.700086	\N	2026-04-01 00:31:43.700031
16	4	1	hi	\N	\N	2026-03-31 00:32:07.527411	2026-03-31 00:32:07.525387	\N	2026-04-01 00:32:07.525337
17	4	3	Ok	\N	\N	2026-03-31 00:33:30.547518	2026-03-31 00:33:30.545489	\N	2026-04-01 00:33:30.545444
18	4	1	k	\N	\N	2026-03-31 00:33:36.802386	2026-03-31 00:33:36.800401	\N	2026-04-01 00:33:36.800347
\.


--
-- Data for Name: group_invitations; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.group_invitations (id, group_id, inviter_id, invited_user_id, status, created_at) FROM stdin;
1	4	1	3	accepted	2026-03-30 22:09:58.180517
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.group_members (id, group_id, user_id, role, joined_at, last_read_at) FROM stdin;
2	1	2	member	2026-03-30 17:21:16.65605	2026-03-30 17:21:16.656074
6	4	1	owner	2026-03-30 22:09:16.278859	2026-03-30 22:09:16.278882
7	4	3	member	2026-03-30 22:10:24.655663	2026-03-30 22:10:24.655687
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.login_history (id, user_id, login_time) FROM stdin;
1	3	2026-03-31 00:26:09.394785
\.


--
-- Data for Name: message_reactions; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.message_reactions (id, message_id, user_id, reaction_type, created_at) FROM stdin;
3	1	3	helpful	2026-03-30 17:44:03.106167
2	1	1	like	2026-03-30 17:21:06.691275
6	3	1	like	2026-03-30 22:11:08.761324
7	3	3	like	2026-03-30 22:11:16.571691
8	6	1	thanks	2026-03-30 22:24:03.425971
12	5	3	thanks	2026-03-30 22:24:47.492033
\.


--
-- Data for Name: message_read_receipts; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.message_read_receipts (id, message_id, user_id, read_at) FROM stdin;
1	2	1	2026-03-30 21:54:56.262519
2	1	3	2026-03-30 22:00:12.893978
3	3	1	2026-03-30 22:11:01.871171
4	4	3	2026-03-30 22:12:59.723638
5	5	3	2026-03-30 22:13:09.183834
6	6	1	2026-03-30 22:14:26.268606
7	7	3	2026-03-30 22:25:09.802865
8	7	1	2026-03-30 22:25:10.050824
9	8	3	2026-03-30 22:25:11.308427
10	8	1	2026-03-30 22:25:11.41728
11	9	3	2026-03-30 22:25:12.897303
12	9	1	2026-03-30 22:25:13.072461
13	10	3	2026-03-30 22:25:17.006577
14	10	1	2026-03-30 22:25:17.383746
15	11	3	2026-03-30 22:25:23.184114
16	11	1	2026-03-30 22:25:23.700033
17	12	3	2026-03-30 22:25:24.162343
18	12	1	2026-03-30 22:25:24.585715
19	13	3	2026-03-30 22:25:31.488895
20	13	1	2026-03-30 22:25:31.838036
21	14	3	2026-03-31 00:31:39.225625
22	15	3	2026-03-31 00:31:45.196083
23	15	1	2026-03-31 00:32:03.649529
24	14	1	2026-03-31 00:32:03.754209
25	16	1	2026-03-31 00:32:08.114249
26	16	3	2026-03-31 00:32:08.766661
27	17	1	2026-03-31 00:33:31.084092
28	17	3	2026-03-31 00:33:31.581529
29	18	1	2026-03-31 00:33:37.443657
30	18	3	2026-03-31 00:33:37.799386
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.messages (id, user_id, recipient_id, encrypted_message, created_at, expires_at, is_read) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.payments (id, user_id, amount, plan, xmr_amount, xmr_address, status, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.sessions (id, session_token, user_id, created_at, expires_at, twofa_verified) FROM stdin;
1	XmDN-F7WAD3Gwh0xpc_SgxTjDdOXedo7bb9oORiezPI	1	2026-03-29 09:43:08.964299	2026-04-05 09:43:08.958003	t
2	btoi8Bd7T4PrnhId5vk0aWB-pr9-KkCiaK1gY1nCABw	2	2026-03-29 09:50:06.653043	2026-04-05 09:50:06.651811	t
3	wzmNK9MFR_JhCj8CZ9h7BXQ8p0MR3h1FJCqsKTzIOrA	1	2026-03-29 11:17:43.375305	2026-04-05 11:18:10.493341	t
4	Q5LiYBoox4BpfjUj-R0nAsdF4wg1yye83Nz2cWG7W5s	3	2026-03-29 12:23:38.252528	2026-04-05 12:23:38.248978	t
5	ZtCdiJuNmr7n-maMldrTR3o3r6Q0ZfMYLdmrUo__YQ0	1	2026-03-29 12:24:54.447297	2026-04-05 12:25:41.454523	t
6	3EeZEc_Hd0owuPBK380wT7lxOKDInvdKspeQ0t84Gn8	3	2026-03-29 12:27:12.958471	2026-04-05 12:27:12.956999	t
7	BGO1j8m8iPLX3ACUP8otrsQaLy2RJ5STsGCuHJduVys	3	2026-03-29 13:15:06.099763	2026-04-05 13:15:06.09477	t
8	XvVGJ8z7BTG-UQlMIjoMZlc8mYPCNI4XEUgtSsaEbIU	1	2026-03-30 13:19:07.556999	2026-04-06 13:19:42.129263	t
9	eOJEDoagTER6F0SfZPg9v-tIFnFfm86t5m4eISDPU6g	3	2026-03-30 14:35:48.8838	2026-04-06 14:35:48.876068	t
10	tslM2SndoY1w5q6CAnb_Ojiz7JEfBXBkw70-CnXRFGM	1	2026-03-30 14:44:41.350155	2026-04-06 14:44:50.945973	t
11	8G8RVGmn6gbsRQ75jPY1C1ShHuTNx3NkXbSBLy1uCDI	3	2026-03-30 15:22:44.759521	2026-04-06 15:22:44.754335	t
12	f75OE_10p1wkFOLnCkbFHlyBdCunghYOlsXt9p3Q8N0	1	2026-03-30 16:59:30.067449	2026-04-06 17:00:16.739715	t
13	J-3MgRU3IjirVLHdvtZVPYZBrQDq1NcaEFP2WcD56WE	1	2026-03-30 17:53:48.735625	2026-04-06 17:53:56.130213	t
14	2n54k1GFyWjO5wo1G-Z6f1pmfT2zK85YJyzrQwHTVWU	3	2026-03-30 21:58:39.733682	2026-04-06 21:58:39.729398	t
15	YJ8-jXrAwg1Gy69KMmNJBWUFfkSrQfSJ4HZmlqp-aIk	3	2026-03-31 00:26:09.476171	2026-04-07 00:26:09.472449	t
\.


--
-- Data for Name: user_keys; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.user_keys (id, user_id, public_key, encrypted_private_key, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dispatch_secure
--

COPY public.users (id, username, password_hash, pin_hash, recovery_phrase_hash, role, created_at, last_login, theme, is_banned, ban_reason, subscription_expires_at, failed_login_attempts, last_failed_login, totp_secret, totp_enabled, recovery_codes_hash, read_receipts_enabled, bio) FROM stdin;
2	Dispatch	$argon2id$v=19$m=65536,t=3,p=4$tfb+f6+1thai9N67FwLAGA$d/mf60l7+8jVJK0O1y+K+iAK2AB7Jf9uWl7y7onmta8	$argon2id$v=19$m=65536,t=3,p=4$d85Z631vbe0dA6B0bu2dcw$ImRlFWekfPWA6jxuzCVPzDu7rM+1zylx3VXZSu8Utuc	$argon2id$v=19$m=65536,t=3,p=4$LSVEyPlfi5Fy7p1zzhkjBA$zeB/99sm8gOsIswXEewIL7NOa+Hl1jbBzS7ZgeIQ74E	premium	2026-03-29 09:47:41.007349	2026-03-29 09:50:06.612185	dark	f	\N	\N	0	\N	\N	f	\N	t	\N
3	Dyspatch	$argon2id$v=19$m=65536,t=3,p=4$1NobIwRAqHUuhVAqpfR+bw$DfAS7q/f1docOPy6njGkWMh3C1O96U1Wt+lAKmq3gus	$argon2id$v=19$m=65536,t=3,p=4$DEFICQEAQCglxPg/p9S69w$/fHVQXvV9sHCUOT1xbhyvfeT3zgEYwnYPfvor/Ps/MU	$argon2id$v=19$m=65536,t=3,p=4$oXTOOQeA8L73vneu1ZoTIg$MXRJWK637gYVwiIROveZEBauJ6EztqW+PQ0IVP2uYZU	pro	2026-03-29 12:23:12.080466	2026-03-31 00:26:09.382754	light	f	\N	\N	0	\N	\N	f	\N	t	\N
1	Admin	$argon2id$v=19$m=65536,t=3,p=4$hVAKQehdKyVkrFVKKYXwvg$pzXabNN5Fgo3ljv/vJuJRsE0zCqNgHx42I3SNFhRH1E	$argon2id$v=19$m=65536,t=3,p=4$BwAgJOT8vxeiVKp1rtV6jw$/J3gs7mWOr5pJi5oP+Kl79piYtLPQtcOqBfbT+EiVNM	$argon2id$v=19$m=65536,t=3,p=4$cQ7hfO9dK2UMIUSo1ZoTgg$hVykdPxu4ndg//i++LSa7Upk42Xp58wl8qcppNYtgFg	owner	2026-03-29 09:41:28.845944	2026-03-30 17:53:56.42004	dark	f	\N	\N	0	\N	KKHUMOGMCLPNEGAJXU2DV5FRHBVMQ5ZC	t	["$argon2id$v=19$m=65536,t=3,p=4$E8J4b03JmdOaMwZA6D0HYA$QKqY+8t5fxXmjSF/neeOpOo4BSARO/SwEuTENek5wZc", "$argon2id$v=19$m=65536,t=3,p=4$W+td6703xtgbg7BWyllrLQ$solAWTdMpMc3KGbwEK9g611+KulHAfJb99OayUiZ6dA", "$argon2id$v=19$m=65536,t=3,p=4$CmFs7Z3TOoeQMkaoFUIoZQ$lEWSBpRisst/YMB9YfdT31DFutvOSZ7965breoD8OkY", "$argon2id$v=19$m=65536,t=3,p=4$whjDmDMmhBAipNQ6pxSilA$UMQ1YfIWbpHjxq/Fjy+5k7Rc0HcS3svzIgVAMDssllA", "$argon2id$v=19$m=65536,t=3,p=4$ao2xdk6plbJWaq01xjiHcA$ssYBlj2JZ1O4mzoETEVzRiYDqbeKutHFsVybfqCL9J8", "$argon2id$v=19$m=65536,t=3,p=4$1VorRUjJOQfA+F+L0do75w$iIak8wuvf3gz7LXh+6ASLg5iUZjq+z7YQTo3xoAjqKw", "$argon2id$v=19$m=65536,t=3,p=4$L0UIodQ6ZwxhDEHonTOm1A$cpaKvtUb59Tb2S2WeN3AqLjOARrZ5fMRbrwwzfSfrzA", "$argon2id$v=19$m=65536,t=3,p=4$E8J4772XkvJei7GW8h5DCA$crU+CAdp1FVTWe2Jd/RcKrM2e2lR+XB8yKW3x0PDGPs", "$argon2id$v=19$m=65536,t=3,p=4$6D0nZGyN0bqXktJaa621lg$MTWAYLG2obfAbrdSwoDR+zNHlBiEF8uMIjnQHJeV8iQ", "$argon2id$v=19$m=65536,t=3,p=4$JUQoBeA8h/Bea21trfV+rw$CctswAxuRuh6cgVzf7xterJFR5MjQZOyLS9nFeKVoWU"]	t	Website Owner.
\.


--
-- Name: blocked_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.blocked_users_id_seq', 1, true);


--
-- Name: chat_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.chat_conversations_id_seq', 2, true);


--
-- Name: chat_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.chat_groups_id_seq', 4, true);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 3, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.files_id_seq', 4, true);


--
-- Name: group_chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.group_chat_messages_id_seq', 18, true);


--
-- Name: group_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.group_invitations_id_seq', 1, true);


--
-- Name: group_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.group_members_id_seq', 7, true);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, true);


--
-- Name: message_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.message_reactions_id_seq', 13, true);


--
-- Name: message_read_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.message_read_receipts_id_seq', 30, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.sessions_id_seq', 15, true);


--
-- Name: user_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.user_keys_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_secure
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: blocked_users blocked_users_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_pkey PRIMARY KEY (id);


--
-- Name: chat_conversations chat_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_pkey PRIMARY KEY (id);


--
-- Name: chat_groups chat_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_groups
    ADD CONSTRAINT chat_groups_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: group_chat_messages group_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_chat_messages
    ADD CONSTRAINT group_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: group_invitations group_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_invitations
    ADD CONSTRAINT group_invitations_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: message_reactions message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_pkey PRIMARY KEY (id);


--
-- Name: message_read_receipts message_read_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_read_receipts
    ADD CONSTRAINT message_read_receipts_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_keys user_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_pkey PRIMARY KEY (id);


--
-- Name: user_keys user_keys_user_id_key; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_blocked_users_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_blocked_users_id ON public.blocked_users USING btree (id);


--
-- Name: ix_chat_conversations_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_chat_conversations_id ON public.chat_conversations USING btree (id);


--
-- Name: ix_chat_groups_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_chat_groups_id ON public.chat_groups USING btree (id);


--
-- Name: ix_chat_messages_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_chat_messages_id ON public.chat_messages USING btree (id);


--
-- Name: ix_files_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_files_id ON public.files USING btree (id);


--
-- Name: ix_group_chat_messages_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_group_chat_messages_id ON public.group_chat_messages USING btree (id);


--
-- Name: ix_group_invitations_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_group_invitations_id ON public.group_invitations USING btree (id);


--
-- Name: ix_group_members_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_group_members_id ON public.group_members USING btree (id);


--
-- Name: ix_login_history_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_login_history_id ON public.login_history USING btree (id);


--
-- Name: ix_message_reactions_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_message_reactions_id ON public.message_reactions USING btree (id);


--
-- Name: ix_message_read_receipts_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_message_read_receipts_id ON public.message_read_receipts USING btree (id);


--
-- Name: ix_messages_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_messages_id ON public.messages USING btree (id);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_sessions_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_sessions_id ON public.sessions USING btree (id);


--
-- Name: ix_sessions_session_token; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE UNIQUE INDEX ix_sessions_session_token ON public.sessions USING btree (session_token);


--
-- Name: ix_user_keys_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_user_keys_id ON public.user_keys USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: dispatch_secure
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: blocked_users blocked_users_blocked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocked_user_id_fkey FOREIGN KEY (blocked_user_id) REFERENCES public.users(id);


--
-- Name: blocked_users blocked_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_initiator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_initiator_id_fkey FOREIGN KEY (initiator_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_user1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_user1_id_fkey FOREIGN KEY (user1_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_user2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_user2_id_fkey FOREIGN KEY (user2_id) REFERENCES public.users(id);


--
-- Name: chat_groups chat_groups_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_groups
    ADD CONSTRAINT chat_groups_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id);


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: files files_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: files files_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: group_chat_messages group_chat_messages_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_chat_messages
    ADD CONSTRAINT group_chat_messages_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.chat_groups(id);


--
-- Name: group_chat_messages group_chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_chat_messages
    ADD CONSTRAINT group_chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: group_invitations group_invitations_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_invitations
    ADD CONSTRAINT group_invitations_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.chat_groups(id);


--
-- Name: group_invitations group_invitations_invited_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_invitations
    ADD CONSTRAINT group_invitations_invited_user_id_fkey FOREIGN KEY (invited_user_id) REFERENCES public.users(id);


--
-- Name: group_invitations group_invitations_inviter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_invitations
    ADD CONSTRAINT group_invitations_inviter_id_fkey FOREIGN KEY (inviter_id) REFERENCES public.users(id);


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.chat_groups(id);


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: login_history login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: message_reactions message_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.group_chat_messages(id);


--
-- Name: message_reactions message_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_reactions
    ADD CONSTRAINT message_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: message_read_receipts message_read_receipts_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_read_receipts
    ADD CONSTRAINT message_read_receipts_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.group_chat_messages(id);


--
-- Name: message_read_receipts message_read_receipts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.message_read_receipts
    ADD CONSTRAINT message_read_receipts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: messages messages_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: messages messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_keys user_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_secure
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dispatch_secure
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO dispatch_secure;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO dispatch_secure;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO dispatch_secure;


--
-- PostgreSQL database dump complete
--

\unrestrict Zrb6mixfkUzIJCbpHnsENQSgG0VQRVXbWywNY64QKrgHubonIldnKiQ3X5Rsku7

