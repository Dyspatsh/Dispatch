--
-- PostgreSQL database dump
--

\restrict cVT83l283abSjq0Mc2YzXEQCa7wagctzgt4tg6Xf1bWPp87GN0UPMhOmcth8rwv

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dispatch_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dispatch_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: dispatch_user
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blocked_users; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.blocked_users (
    id integer NOT NULL,
    user_id integer NOT NULL,
    blocked_user_id integer NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.blocked_users OWNER TO dispatch_user;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.blocked_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blocked_users_id_seq OWNER TO dispatch_user;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.blocked_users_id_seq OWNED BY public.blocked_users.id;


--
-- Name: chat_conversations; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.chat_conversations (
    id integer NOT NULL,
    user1_id integer NOT NULL,
    user2_id integer NOT NULL,
    status character varying(20),
    initiator_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.chat_conversations OWNER TO dispatch_user;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.chat_conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_conversations_id_seq OWNER TO dispatch_user;

--
-- Name: chat_conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.chat_conversations_id_seq OWNED BY public.chat_conversations.id;


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.chat_messages (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    encrypted_content text NOT NULL,
    created_at timestamp without time zone,
    delivered_at timestamp without time zone,
    read_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO dispatch_user;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.chat_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_messages_id_seq OWNER TO dispatch_user;

--
-- Name: chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.chat_messages_id_seq OWNED BY public.chat_messages.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.files (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    recipient_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    encrypted_filename character varying(255) NOT NULL,
    file_size bigint NOT NULL,
    status character varying(20),
    options text,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    accepted_at timestamp without time zone,
    downloaded_at timestamp without time zone,
    stealth_mode boolean
);


ALTER TABLE public.files OWNER TO dispatch_user;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO dispatch_user;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    user_id integer NOT NULL,
    recipient_id integer NOT NULL,
    encrypted_message text NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    is_read boolean
);


ALTER TABLE public.messages OWNER TO dispatch_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO dispatch_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount integer NOT NULL,
    plan character varying(20) NOT NULL,
    xmr_amount character varying(50) NOT NULL,
    xmr_address character varying(255) NOT NULL,
    status character varying(20),
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO dispatch_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO dispatch_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    twofa_verified boolean
);


ALTER TABLE public.sessions OWNER TO dispatch_user;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO dispatch_user;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: user_keys; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.user_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    public_key text NOT NULL,
    encrypted_private_key text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.user_keys OWNER TO dispatch_user;

--
-- Name: user_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.user_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_keys_id_seq OWNER TO dispatch_user;

--
-- Name: user_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.user_keys_id_seq OWNED BY public.user_keys.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: dispatch_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    pin_hash character varying(255) NOT NULL,
    recovery_phrase_hash character varying(255) NOT NULL,
    role character varying(20),
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    theme character varying(10),
    is_banned boolean,
    ban_reason text,
    subscription_expires_at timestamp without time zone,
    failed_login_attempts integer,
    last_failed_login timestamp without time zone,
    totp_secret character varying(100),
    totp_enabled boolean,
    recovery_codes_hash text
);


ALTER TABLE public.users OWNER TO dispatch_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dispatch_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dispatch_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dispatch_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: blocked_users id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.blocked_users ALTER COLUMN id SET DEFAULT nextval('public.blocked_users_id_seq'::regclass);


--
-- Name: chat_conversations id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_conversations ALTER COLUMN id SET DEFAULT nextval('public.chat_conversations_id_seq'::regclass);


--
-- Name: chat_messages id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_messages ALTER COLUMN id SET DEFAULT nextval('public.chat_messages_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: user_keys id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.user_keys ALTER COLUMN id SET DEFAULT nextval('public.user_keys_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: blocked_users; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.blocked_users (id, user_id, blocked_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: chat_conversations; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.chat_conversations (id, user1_id, user2_id, status, initiator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.chat_messages (id, conversation_id, sender_id, encrypted_content, created_at, delivered_at, read_at, expires_at) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.files (id, sender_id, recipient_id, filename, encrypted_filename, file_size, status, options, created_at, expires_at, accepted_at, downloaded_at, stealth_mode) FROM stdin;
2	1	3	0f766e.png	ad1b64d5312c03aba2885b279867d0c8ef1e5bff45b1412f1b6f978f93778c10.enc	6821	declined	{"custom_expiry": 1}	2026-03-29 12:32:41.076546	2026-04-01 12:32:41.06987	\N	\N	f
3	1	3	rules.docx	61cdb7dbc047afa1b9c1ae7cc0a6851c3265914761231e85cf256df0292cbea8.enc	27578	accepted	{}	2026-03-29 12:33:53.876468	2026-04-05 12:34:56.297844	2026-03-29 12:34:56.298012	\N	f
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.messages (id, user_id, recipient_id, encrypted_message, created_at, expires_at, is_read) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.payments (id, user_id, amount, plan, xmr_amount, xmr_address, status, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.sessions (id, session_token, user_id, created_at, expires_at, twofa_verified) FROM stdin;
1	XmDN-F7WAD3Gwh0xpc_SgxTjDdOXedo7bb9oORiezPI	1	2026-03-29 09:43:08.964299	2026-04-05 09:43:08.958003	t
2	btoi8Bd7T4PrnhId5vk0aWB-pr9-KkCiaK1gY1nCABw	2	2026-03-29 09:50:06.653043	2026-04-05 09:50:06.651811	t
3	wzmNK9MFR_JhCj8CZ9h7BXQ8p0MR3h1FJCqsKTzIOrA	1	2026-03-29 11:17:43.375305	2026-04-05 11:18:10.493341	t
4	Q5LiYBoox4BpfjUj-R0nAsdF4wg1yye83Nz2cWG7W5s	3	2026-03-29 12:23:38.252528	2026-04-05 12:23:38.248978	t
5	ZtCdiJuNmr7n-maMldrTR3o3r6Q0ZfMYLdmrUo__YQ0	1	2026-03-29 12:24:54.447297	2026-04-05 12:25:41.454523	t
6	3EeZEc_Hd0owuPBK380wT7lxOKDInvdKspeQ0t84Gn8	3	2026-03-29 12:27:12.958471	2026-04-05 12:27:12.956999	t
7	BGO1j8m8iPLX3ACUP8otrsQaLy2RJ5STsGCuHJduVys	3	2026-03-29 13:15:06.099763	2026-04-05 13:15:06.09477	t
\.


--
-- Data for Name: user_keys; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.user_keys (id, user_id, public_key, encrypted_private_key, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dispatch_user
--

COPY public.users (id, username, password_hash, pin_hash, recovery_phrase_hash, role, created_at, last_login, theme, is_banned, ban_reason, subscription_expires_at, failed_login_attempts, last_failed_login, totp_secret, totp_enabled, recovery_codes_hash) FROM stdin;
2	Dispatch	$argon2id$v=19$m=65536,t=3,p=4$tfb+f6+1thai9N67FwLAGA$d/mf60l7+8jVJK0O1y+K+iAK2AB7Jf9uWl7y7onmta8	$argon2id$v=19$m=65536,t=3,p=4$d85Z631vbe0dA6B0bu2dcw$ImRlFWekfPWA6jxuzCVPzDu7rM+1zylx3VXZSu8Utuc	$argon2id$v=19$m=65536,t=3,p=4$LSVEyPlfi5Fy7p1zzhkjBA$zeB/99sm8gOsIswXEewIL7NOa+Hl1jbBzS7ZgeIQ74E	premium	2026-03-29 09:47:41.007349	2026-03-29 09:50:06.612185	dark	f	\N	\N	0	\N	\N	f	\N
3	Dyspatch	$argon2id$v=19$m=65536,t=3,p=4$1NobIwRAqHUuhVAqpfR+bw$DfAS7q/f1docOPy6njGkWMh3C1O96U1Wt+lAKmq3gus	$argon2id$v=19$m=65536,t=3,p=4$DEFICQEAQCglxPg/p9S69w$/fHVQXvV9sHCUOT1xbhyvfeT3zgEYwnYPfvor/Ps/MU	$argon2id$v=19$m=65536,t=3,p=4$oXTOOQeA8L73vneu1ZoTIg$MXRJWK637gYVwiIROveZEBauJ6EztqW+PQ0IVP2uYZU	pro	2026-03-29 12:23:12.080466	2026-03-29 13:15:06.052457	light	f	\N	\N	0	\N	\N	f	\N
1	Admin	$argon2id$v=19$m=65536,t=3,p=4$hVAKQehdKyVkrFVKKYXwvg$pzXabNN5Fgo3ljv/vJuJRsE0zCqNgHx42I3SNFhRH1E	$argon2id$v=19$m=65536,t=3,p=4$BwAgJOT8vxeiVKp1rtV6jw$/J3gs7mWOr5pJi5oP+Kl79piYtLPQtcOqBfbT+EiVNM	$argon2id$v=19$m=65536,t=3,p=4$cQ7hfO9dK2UMIUSo1ZoTgg$hVykdPxu4ndg//i++LSa7Upk42Xp58wl8qcppNYtgFg	owner	2026-03-29 09:41:28.845944	2026-03-29 12:25:41.492388	dark	f	\N	\N	0	\N	KKHUMOGMCLPNEGAJXU2DV5FRHBVMQ5ZC	t	["$argon2id$v=19$m=65536,t=3,p=4$E8J4b03JmdOaMwZA6D0HYA$QKqY+8t5fxXmjSF/neeOpOo4BSARO/SwEuTENek5wZc", "$argon2id$v=19$m=65536,t=3,p=4$W+td6703xtgbg7BWyllrLQ$solAWTdMpMc3KGbwEK9g611+KulHAfJb99OayUiZ6dA", "$argon2id$v=19$m=65536,t=3,p=4$CmFs7Z3TOoeQMkaoFUIoZQ$lEWSBpRisst/YMB9YfdT31DFutvOSZ7965breoD8OkY", "$argon2id$v=19$m=65536,t=3,p=4$whjDmDMmhBAipNQ6pxSilA$UMQ1YfIWbpHjxq/Fjy+5k7Rc0HcS3svzIgVAMDssllA", "$argon2id$v=19$m=65536,t=3,p=4$ao2xdk6plbJWaq01xjiHcA$ssYBlj2JZ1O4mzoETEVzRiYDqbeKutHFsVybfqCL9J8", "$argon2id$v=19$m=65536,t=3,p=4$1VorRUjJOQfA+F+L0do75w$iIak8wuvf3gz7LXh+6ASLg5iUZjq+z7YQTo3xoAjqKw", "$argon2id$v=19$m=65536,t=3,p=4$L0UIodQ6ZwxhDEHonTOm1A$cpaKvtUb59Tb2S2WeN3AqLjOARrZ5fMRbrwwzfSfrzA", "$argon2id$v=19$m=65536,t=3,p=4$E8J4772XkvJei7GW8h5DCA$crU+CAdp1FVTWe2Jd/RcKrM2e2lR+XB8yKW3x0PDGPs", "$argon2id$v=19$m=65536,t=3,p=4$6D0nZGyN0bqXktJaa621lg$MTWAYLG2obfAbrdSwoDR+zNHlBiEF8uMIjnQHJeV8iQ", "$argon2id$v=19$m=65536,t=3,p=4$JUQoBeA8h/Bea21trfV+rw$CctswAxuRuh6cgVzf7xterJFR5MjQZOyLS9nFeKVoWU"]
\.


--
-- Name: blocked_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.blocked_users_id_seq', 1, true);


--
-- Name: chat_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.chat_conversations_id_seq', 1, false);


--
-- Name: chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.chat_messages_id_seq', 1, false);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.files_id_seq', 3, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.sessions_id_seq', 7, true);


--
-- Name: user_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.user_keys_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dispatch_user
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: blocked_users blocked_users_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_pkey PRIMARY KEY (id);


--
-- Name: chat_conversations chat_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_keys user_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_pkey PRIMARY KEY (id);


--
-- Name: user_keys user_keys_user_id_key; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_blocked_users_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_blocked_users_id ON public.blocked_users USING btree (id);


--
-- Name: ix_chat_conversations_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_chat_conversations_id ON public.chat_conversations USING btree (id);


--
-- Name: ix_chat_messages_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_chat_messages_id ON public.chat_messages USING btree (id);


--
-- Name: ix_files_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_files_id ON public.files USING btree (id);


--
-- Name: ix_messages_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_messages_id ON public.messages USING btree (id);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_sessions_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_sessions_id ON public.sessions USING btree (id);


--
-- Name: ix_sessions_session_token; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE UNIQUE INDEX ix_sessions_session_token ON public.sessions USING btree (session_token);


--
-- Name: ix_user_keys_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_user_keys_id ON public.user_keys USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: dispatch_user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: blocked_users blocked_users_blocked_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocked_user_id_fkey FOREIGN KEY (blocked_user_id) REFERENCES public.users(id);


--
-- Name: blocked_users blocked_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_initiator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_initiator_id_fkey FOREIGN KEY (initiator_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_user1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_user1_id_fkey FOREIGN KEY (user1_id) REFERENCES public.users(id);


--
-- Name: chat_conversations chat_conversations_user2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_conversations
    ADD CONSTRAINT chat_conversations_user2_id_fkey FOREIGN KEY (user2_id) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.chat_conversations(id);


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: files files_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: files files_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: messages messages_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: messages messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_keys user_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dispatch_user
--

ALTER TABLE ONLY public.user_keys
    ADD CONSTRAINT user_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dispatch_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict cVT83l283abSjq0Mc2YzXEQCa7wagctzgt4tg6Xf1bWPp87GN0UPMhOmcth8rwv

